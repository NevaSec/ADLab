GestionClients - application interne de gestion de la relation client.

Version : 1.4.2
Maintenue par : service IT NEVASEC

Pour lancer l'application, double-cliquer sur GestionClients.exe.
En cas de probleme, consulter le dossier logs\ puis contacter it-support@nevasec.fr.
